package org.openjfx.javaFX;

import javafx.animation.*;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.control.Alert;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Text;
import javafx.scene.transform.Rotate;
import javafx.util.Duration;
import jsonStuff.WelshDictionary;

import java.util.Stack;

public class PrimaryController {
    int score = 0;
    int index = 0;
    Node card;

    @FXML
    private Text counter;
    @FXML
    private TextField englishDef;
    @FXML
    private Rectangle flashcard;
    @FXML
    private Text tester;

@FXML
private void initialize(){
    tester.setText("Welsh Word: \t"+App.words.getFirst().getWelsh());
    counter.setText("Correct: "+ score);
    card = flashcard;
}
    @FXML
    protected void addButtonClick(ActionEvent actionEvent) {

    checkAnswer(englishDef.getText());
    index++;
    RotateTransition rotator = RotateCard(card);
    rotator.play();
    }

    private void checkAnswer(String english) {

        if (App.words.get(index).getEnglish().equals(english)) {
            score++;
        }

        counter.setText("Correct: " + score);
    }
    private RotateTransition RotateCard(Node card){

        RotateTransition rotate = new RotateTransition(Duration.millis(1000), card);
        tester.setVisible(false);
        englishDef.setVisible(false);

        rotate.setAxis(Rotate.Y_AXIS);
        rotate.setFromAngle(0);
        rotate.setToAngle(360);
        rotate.setInterpolator(Interpolator.LINEAR);
        rotate.setCycleCount(1);
        rotate.setOnFinished(event -> {

            englishDef.setText("");
            tester.setText("Welsh word: \t"+App.words.get(index).getWelsh());
            tester.setVisible(true);
            englishDef.setVisible(true);
        });
        return rotate;

    }


}
